import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export class Payment {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  medicineId: string;

  @Column()
  patientId: string;

  @Column("decimal", { precision: 10, scale: 2 })
  totalPayment: number;

  @Column()
  paymentOption: string;
}
