import { Controller } from '@nestjs/common';

@Controller('inventory')
export class InventoryController {}
