import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('login')
export class Login {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @Column()
  nid: number;

  @Column({ nullable: true })
  phoneNumber: string;

}
