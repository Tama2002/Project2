import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoginModule } from './login/login.module';
import { Login } from './login/login.entity';
import { InventoryModule } from './inventory/inventory.module';
import { PaymentModule } from './payment/payment.module';
import { Payment } from './payment/payment.entity';
import { Inventory } from './inventory/inventory.entity';
@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'postgres',
      password: 'tama',
      database: 'pharmacist',
      entities: [Login, Payment, Inventory],
      synchronize: true,
    }),
    LoginModule,
    InventoryModule,
    PaymentModule,
 
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
